// Tom Wexler

import java.util.*;
import java.io.*;

class bucket {
    //HashSet<Integer> b;
    ArrayList<Integer> l;
    //boolean[] table;
    public bucket() {
        //b = new HashSet<Integer>();
        l = new ArrayList<Integer>();
    }
}

public class D {
    public static void main(String[] args) {
//        long time = System.currentTimeMillis();
        Scanner input = new Scanner(System.in);
        String line = input.next();
        int[] v = new int[100];
        int n = 0;
        int caseNo = 1;
        while (line.charAt(0) != '0') {
            n = line.length();
            bucket[][] table = new bucket[50][50];
            boolean[][][] tab = new boolean[50][50][5001];
            for(int i = 0; i < n; i++) {
                char c = line.charAt(i);
                switch (c) {
                    case 'I':
                        v[i] = 1;
                        break;
                    case 'V':
                        v[i] = 5;
                        break;
                    case 'X':
                        v[i] = 10;
                        break;
                    case 'L':
                        v[i] = 50;
                        break;
                    case 'C':
                        v[i] = 100;
                        break;
                }
                
            }
            for(int i = 0; i < n; i++) {
                table[i][i] = new bucket();
                //table[i][i].b.add(v[i]);
                table[i][i].l.add(v[i]);
            }
            for(int width = 1; width < n; width++) {
                for(int start = 0; start < n-width; start++) {
                    int end = start+width;
                    table[start][end] = new bucket();
                    for(int split = start; split < end; split++) {
                        for(int a : table[start][split].l) {
                            for(int b : table[split+1][end].l) {
                                int newnum = b-a;
                                if (a >= b) {
                                    newnum = a+b;
                                    //if (!table[start][end].b.contains(a+b)) {
                                    //    table[start][end].b.add(a+b);
                                    //    table[start][end].l.add(a+b);
                                    //}
                                }
                                //else {
                                    //if (!table[start][end].b.contains(b-a)) {
                                    //    table[start][end].b.add(b-a);
                                    //    table[start][end].l.add(b-a);
                                    //}
                                //}
                                if (!tab[start][end][newnum]) {
                                    tab[start][end][newnum] = true;
                                    table[start][end].l.add(newnum);
                                }
                            }
                        }
                    }
                }
            }/*
            ArrayList<Integer> sorted = new ArrayList<Integer>();
            for(int a :table[0][n-1].b) {
                sorted.add(a);
            }
            Collections.sort(sorted);*/
            Collections.sort(table[0][n-1].l);
            System.out.print("Case "+caseNo+":");
            for(int a : table[0][n-1].l) {
                System.out.print(" "+a);
            }
            System.out.println();
            caseNo++;
            
            line = input.next();
        }
//        System.out.println(System.currentTimeMillis()-time);
    }
}
