// Tom Wexler

import java.util.*;
import java.io.*;

public class A {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        int n1 = input.nextInt();
        int n2 = input.nextInt();
        int caseNo = 1;
        while (n1 > 0) {
            int[] a1 = new int[n1];
            int[] a2 = new int[n2];
            for (int i = 0; i < n1; i++) {
               a1[i] = input.nextInt();
            }
            for (int i = 0; i < n2; i++) {
               a2[i] = input.nextInt();
            }
            long[] r1 = toRational(a1);
            long[] r2 = toRational(a2);
            System.out.println("Case "+caseNo+":");
            //System.out.println(r1[0]+"/"+r1[1]);
            print(toFrac(r1[0]*r2[1]+r2[0]*r1[1], r1[1]*r2[1]));
            print(toFrac(r1[0]*r2[1]-r2[0]*r1[1], r1[1]*r2[1]));
            print(toFrac(r1[0]*r2[0], r1[1]*r2[1]));
            print(toFrac(r1[0]*r2[1], r2[0]*r1[1]));
            n1 = input.nextInt();
            n2 = input.nextInt();
            caseNo++;
        }
    }
    
    public static void print(ArrayList<Long> L) {
        for(int i = 0; i < L.size()-1; i++) {
            System.out.print(L.get(i) + " ");
        }
        System.out.println(L.get(L.size()-1));
    }
    
    public static ArrayList<Long> toFrac(long n, long d) {
        if (d < 0) {
            n = -n;
            d = -d;
        }
        ArrayList<Long> L = new ArrayList<Long>();
        //System.out.println("Called toFrac on "+n+" "+d);
        if (n < 0 && n%d == 0) {
            L.add(new Long(n/d));    
        }
        else if (n < 0) {
            L.add(new Long(n/d-1));
            L.addAll(toFrac(d, n%d+d));
        }
        else {
            L.add(new Long(n/d));
            if (n%d != 0) {
                L.addAll(toFrac(d, n%d));
            }
        }
        return L;
    }
    
    public static long[] toRational(int[] a) {
        return toRational(a, a.length-1, 0, 1);
    }
    
    public static long[] toRational(int[] a, int index, long n, long d) {
        if (index < 0) {
            long[] r = new long[2];
            r[0] = d;
            r[1] = n;
            return r;
        }
        else {
            return toRational(a, index-1, d, d*a[index]+n);
        }
    }
    
}
